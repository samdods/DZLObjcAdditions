//
//  DZLMixin.h
//  MixinExample
//
//  Created by Sam Dods on 13/05/2014.
//  Copyright (c) 2014 Sam Dods. All rights reserved.
//

#import <Foundation/Foundation.h>

#define MixinBegin(name, class, superclass) \
@interface name : superclass @end \
@implementation name \
+ (void)load { [class mixin:self]; }

#define MixinEnd @end


@interface NSObject (DZLMixin)

+ (void)mixin:(Class)mixinClass;

@end
