//
//  DZLMixin.m
//  MixinExample
//
//  Created by Sam Dods on 13/05/2014.
//  Copyright (c) 2014 Sam Dods. All rights reserved.
//

#import <objc/runtime.h>
#import "DZLMixin.h"


@implementation NSObject (DZLMixin)

+ (void)mixin:(Protocol *)mixinProtocol
{
  const char *protocolName = protocol_getName(mixinProtocol);
  NSString *className = [NSString stringWithFormat:@"%sMixinProtocol_", protocolName];
  [self dzl_mixinClass:NSClassFromString(className) overrideSuper:NO];
}

+ (void)dzl_mixinClass:(Class)mixinClass
{
  [self dzl_mixinClass:mixinClass overrideSuper:YES];
}

+ (void)dzl_mixinClass:(Class)mixinClass overrideSuper:(BOOL)shouldOverrideSuper
{
  uint numberOfMethods;
  Method *methods = class_copyMethodList(mixinClass, &numberOfMethods);
  for (uint m = 0; m < numberOfMethods; m++) {
    Method method = methods[m];
    SEL name = method_getName(method);
    if (!shouldOverrideSuper && [self instancesRespondToSelector:name]) {
      continue;
    }
    IMP imp = method_getImplementation(method);
    const char *types = method_getTypeEncoding(method);
    class_addMethod(self, name, imp, types);
  }
  free(methods);
}

@end
