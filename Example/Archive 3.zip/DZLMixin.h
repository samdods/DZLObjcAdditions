//
//  DZLMixin.h
//  MixinExample
//
//  Created by Sam Dods on 13/05/2014.
//  Copyright (c) 2014 Sam Dods. All rights reserved.
//

#import <objc/message.h>
#import <Foundation/Foundation.h>


#define safeSuper(...) \
struct objc_super dzlSuperClass_ = {self, self.class.superclass}; \
objc_msgSendSuper(&dzlSuperClass_, _cmd, __VA_ARGS__);


#define implementationsafe(class, name) \
interface name ## class ## Mixin : NSObject @end \
@implementation name ## class ## Mixin \
+ (void)load \
{ \
[class dzl_mixinClass:self]; \
}


#define protocolimplementation(name) \
interface name ## MixinProtocol_ : NSObject @end \
@implementation name ## MixinProtocol_ \


@interface NSObject (DZLMixin)

+ (void)mixin:(Protocol *)mixinProtocol;

+ (void)dzl_mixinClass:(Class)mixinClass;

@end
