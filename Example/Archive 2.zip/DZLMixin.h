//
//  DZLMixin.h
//  MixinExample
//
//  Created by Sam Dods on 13/05/2014.
//  Copyright (c) 2014 Sam Dods. All rights reserved.
//

#import <objc/message.h>
#import <Foundation/Foundation.h>


#define mixinSuper(...) \
struct objc_super dzlSuperClass_ = {self, self.class.superclass}; \
objc_msgSendSuper(&dzlSuperClass_, _cmd, __VA_ARGS__);

#define mixin(class, name) \
interface Mixin ## name ## class : NSObject @end \
@implementation Mixin ## name ## class : NSObject \
+ (void)load \
{ \
[class dzl_mixin:self]; \
}


@interface NSObject (DZLMixin)

+ (void)dzl_mixin:(Class)mixinClass;

@end
