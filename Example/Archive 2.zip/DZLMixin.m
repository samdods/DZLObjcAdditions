//
//  DZLMixin.m
//  MixinExample
//
//  Created by Sam Dods on 13/05/2014.
//  Copyright (c) 2014 Sam Dods. All rights reserved.
//

#import <objc/runtime.h>
#import "DZLMixin.h"


@implementation NSObject (DZLMixin)

+ (void)dzl_mixin:(Class)mixinClass
{
  uint numberOfMethods;
  Method *methods = class_copyMethodList(mixinClass, &numberOfMethods);
  for (uint m = 0; m < numberOfMethods; m++) {
    Method method = methods[m];
    SEL name = method_getName(method);
    IMP imp = method_getImplementation(method);
    const char *types = method_getTypeEncoding(method);
    class_addMethod(self, name, imp, types);
  }
  free(methods);
}

@end
